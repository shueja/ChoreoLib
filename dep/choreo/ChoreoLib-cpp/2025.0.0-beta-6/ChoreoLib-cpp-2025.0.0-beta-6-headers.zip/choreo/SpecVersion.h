// Copyright (c) Choreo contributors

#pragma once

#include <string_view>

namespace choreo {

inline constexpr std::string_view kSpecVersion = "v2025.0.0";

}  // namespace choreo
